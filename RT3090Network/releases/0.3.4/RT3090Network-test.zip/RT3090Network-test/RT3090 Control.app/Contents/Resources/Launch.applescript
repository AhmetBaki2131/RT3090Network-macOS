on run argv
    set guiFile to item 1 of argv
    do shell script "/usr/bin/python " & quoted form of guiFile with administrator privileges
end run
