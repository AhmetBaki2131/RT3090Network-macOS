bool RT3090Network::start(IOService *provider)
{
    const char *stage="super start";
    if(!IOEthernetController::start(provider)) { IOLog("RT3090Network: superclass start failed\n"); return false; }
    stage="PCI provider";
    pci=((IOPCIDevice *) OSMetaClassBase::safeMetaCast((provider), (IOPCIDevice::metaClass)));
    if(!pci) goto fail;
    pci->retain();
    stage="PCI identity";
    if(pci->configRead16(kIOPCIConfigVendorID)!=0x1814 || pci->configRead16(kIOPCIConfigDeviceID)!=0x3090 ||
        pci->configRead16(kIOPCIConfigSubSystemVendorID)!=0x103c || pci->configRead16(kIOPCIConfigSubSystemID)!=0x1453) goto fail;
    setProperty("RT3090Mode","pci-diagnostic");
    setProperty("RT3090WindowsLocationHint","PCIROOT(0)#PCI(1C00)#PCI(0000)");
    setProperty("RT3090PCIMatched",true);
    setProperty("RT3090VendorID",pci->configRead16(kIOPCIConfigVendorID),32);
    setProperty("RT3090DeviceID",pci->configRead16(kIOPCIConfigDeviceID),32);
    setProperty("RT3090SubsystemVendorID",pci->configRead16(kIOPCIConfigSubSystemVendorID),32);
    setProperty("RT3090SubsystemID",pci->configRead16(kIOPCIConfigSubSystemID),32);
    setProperty("RT3090PCIRevision",pci->configRead8(kIOPCIConfigRevisionID),32);
    setProperty("RT3090Status","PCI match only; firmware, MMIO, DMA, IRQ and radio not started");
    IOLog("RT3090Network: PCI-only diagnostic attached; no device writes\n");
    registerService(); return true;
fail:
    IOLog("RT3090Network: start rejected at %s\n",stage);
    if(pci) { pci->setProperty("RT3090LastStartError",stage); pci->setProperty("RT3090LastAttemptVersion","0.3.4"); }
    cleanup(); IOEthernetController::stop(provider); return false;
}
